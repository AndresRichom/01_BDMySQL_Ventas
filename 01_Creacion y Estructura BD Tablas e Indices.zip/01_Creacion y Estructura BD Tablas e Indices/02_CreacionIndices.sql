/*Creacion de indices:
Lo usaremos en las futuras busquedas con where, etc.*/

use BDEmpresa;

alter table tbl_vendedor
add index idx_id_vendedor (id_vendedor);

alter table tbl_cliente
add index idx_id_cliente (id_cliente);

alter table tbl_categoria
add index idx_id_categoria (id_categoria);

alter table tbl_producto
add index idx_id_producto (id_producto);

alter table tbl_metodo_pago
add index idx_id_metodo_pago (id_metodo_pago);

alter table tbl_factura
add index idx_id_factura (id_factura);

alter table tbl_detalle_factura
add index idx_id_detalle (id_detalle);

