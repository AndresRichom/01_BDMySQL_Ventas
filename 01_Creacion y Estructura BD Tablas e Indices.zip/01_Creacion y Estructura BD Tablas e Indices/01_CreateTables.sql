create schema BDEmpresa;
use BDEmpresa;

CREATE TABLE tbl_vendedor (
    id_vendedor INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(100) NOT NULL,
    apellido VARCHAR(100) NOT NULL,
    telefono VARCHAR(20),
    email VARCHAR(100),
    fecha_contratacion DATE
);

CREATE TABLE tbl_cliente (
    id_cliente INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(100) NOT NULL,
    apellido VARCHAR(100),
    direccion VARCHAR(150),
    telefono VARCHAR(20),
    email VARCHAR(100)
);

CREATE TABLE tbl_categoria (
    id_categoria INT PRIMARY KEY AUTO_INCREMENT,
    nombre_categoria VARCHAR(100) NOT NULL,
    descripcion VARCHAR(150)
);

/*Aparte de la tabla crearemos los forign key usando references */
CREATE TABLE tbl_producto (
    id_producto INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(100) NOT NULL,
    precio DECIMAL(10,2) NOT NULL,
    stock INT NOT NULL,
    id_categoria INT,
    FOREIGN KEY (id_categoria) REFERENCES tbl_categoria(id_categoria) 
);

CREATE TABLE tbl_metodo_pago (
    id_metodo_pago INT PRIMARY KEY AUTO_INCREMENT,
    descripcion VARCHAR(50) NOT NULL
);

CREATE TABLE tbl_factura (
    id_factura INT PRIMARY KEY AUTO_INCREMENT,
    fecha DATE NOT NULL,
    id_cliente INT,
    id_vendedor INT,
    id_metodo_pago INT,
    total DECIMAL(10,2),
    FOREIGN KEY (id_cliente) REFERENCES tbl_cliente(id_cliente),
    FOREIGN KEY (id_vendedor) REFERENCES tbl_vendedor(id_vendedor),
    FOREIGN KEY (id_metodo_pago) REFERENCES tbl_metodo_pago(id_metodo_pago)
);

CREATE TABLE tbl_detalle_factura (
    id_detalle INT PRIMARY KEY AUTO_INCREMENT,
    id_factura INT,
    id_producto INT,
    cantidad INT NOT NULL,
    precio_unitario DECIMAL(10,2) NOT NULL,
    subtotal DECIMAL(10,2),
    FOREIGN KEY (id_factura) REFERENCES tbl_factura(id_factura),
    FOREIGN KEY (id_producto) REFERENCES tbl_producto(id_producto)
);