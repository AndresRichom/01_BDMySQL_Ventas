use BDEmpresa;
# Creacion de View:

create view VW_Stock_Categoria as
select sum(a.stock) as Total_Stock, b.nombre_categoria
	from tbl_producto a
	inner join tbl_categoria b
	on a.id_categoria = b.id_categoria
group by b.nombre_categoria;

# Ejecutar view:
select * from Stock_Categoria;

#----------------------------------------------
create view VW_Stock_producto as
select sum(a.stock) as Total_Stock, a.nombre, b.nombre_categoria
	from tbl_producto a
	inner join tbl_categoria b
	on a.id_categoria = b.id_categoria
group by a.nombre, b.nombre_categoria;

# Ejecutar view:
select * from stock_producto;

#----------------------------------------------

