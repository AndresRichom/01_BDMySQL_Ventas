use BDEmpresa;
#Creacion de procedimientos almacenados:
#---------------------------------------
DELIMITER $$
CREATE PROCEDURE `proc_prod_vend`(
in nombre_producto varchar(100))
BEGIN
	select a.nombre, sum(b.cantidad), sum(b.precio_unitario) as Total_Prec_Unitario
		from tbl_producto a
		inner join tbl_detalle_factura b
		on a.id_producto = b.id_producto
	where a.nombre = nombre_producto
    group by a.nombre;
END $$
DELIMITER ;

# Ejecutar Procedimiento almacenado Ingresa el Nombre del Producto:
CALL proc_prod_vend ('Pantalla HP 15 vga-hdmi');

#---------------------------------------
DELIMITER $$
USE `BDEmpresa`$$
CREATE PROCEDURE `proc_ventas_bajas_vendedor` (
in id_vendedor int)
BEGIN
	select a.id_vendedor,a.fecha, a.total
		from tbl_factura a
	where a.total <= 100000 and a.id_vendedor = 2;
END$$

DELIMITER ;

# Ejecutar Procedimiento almacenado ingresa el ID del Vendedor:
CALL proc_ventas_bajas_vendedor ('2');

#-------------------------------------------
DELIMITER $$
USE `BDEmpresa`$$
CREATE PROCEDURE `proc_actua_precio`(
	IN p_id_producto INT,
	IN precio_nuevo DECIMAL(10,2))
BEGIN
	UPDATE tbl_producto
    SET precio = precio_nuevo
    WHERE id_producto = p_id_producto;
END$$
DELIMITER ;

#Ejecutar procedimiento (Ingresa el ID del producto y el nuevo precio)
call proc_actua_precio (1,35000);

