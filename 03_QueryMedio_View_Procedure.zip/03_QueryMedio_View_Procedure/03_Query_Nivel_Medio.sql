use BDEmpresa;

#Habilitacion del Full group by:
SET sql_mode=(SELECT REPLACE(@@sql_mode,'ONLY_FULL_GROUP_BY',''));

/*Cantidad Total vendidad por categoria: */
select a.nombre_categoria, sum(c.cantidad) as total_cantidad
	from tbl_categoria a 
	inner join tbl_producto b
	on a.id_categoria = b.id_categoria
	inner join tbl_detalle_factura c
	on b.id_categoria = c.id_producto 
group by a.nombre_categoria;

# Revision de stock a comprar
select a.nombre, if(a.stock < 15, 'Gestionar Compra', 'Stock Ok')
from tbl_producto a;

# Revision de las ventas por categoria:
select a.nombre, sum(b.cantidad) as suma_vendida,
	case
		when SUM(b.cantidad) >= 30 THEN 'Venta Alta'
        when SUM(b.cantidad) BETWEEN 21 AND 30 THEN 'Venta Media'
        when SUM(b.cantidad) <= 20 THEN 'Venta Baja'
        else 'Productos no vendidos'
	end as Ventas
from tbl_producto a
inner join tbl_detalle_factura b
on a.id_producto = b.id_producto
group by a.nombre;

# Lista de los clientes que han comprado:
select a.nombre, monthname(b.fecha) as mes, sum(b.total) as total_vendido
	from tbl_cliente a
	inner join tbl_factura b
	on a.id_cliente = b.id_cliente
group by a.nombre
order by a.nombre asc;

#Mostrar todas las ventas superior a 140000
select b.nombre, sum(a.total) as venta_total_vendedores
	from tbl_factura a 
	inner join tbl_vendedor b
	on a.id_vendedor = b.id_vendedor
where a.total >= 140000
group by b.nombre;

#Cantidad de software vendido durante el año 2021:
select d.nombre_categoria, monthname(a.fecha) as mes, year(a.fecha) as año, sum(b.cantidad) as Cantidad_Vendida
	from tbl_factura a 
	inner join tbl_detalle_factura b
	on a.id_factura = b.id_factura
	inner join tbl_producto c
	on b.id_producto = c.id_producto
	inner join tbl_categoria d
	on c.id_categoria = d.id_categoria
where d.nombre_categoria = "Software"
and year(a.fecha) = 2021
group by d.nombre_categoria, mes, año;

